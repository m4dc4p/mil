#include <stdio.h>

extern int f(int*);

int main() {
  int a[] = { 5, 3, -6, 8, 2, -10, 11, -9, 1, 4, -7, 0 };
  printf("result is %d\n", f(a));
  return 0;
}
